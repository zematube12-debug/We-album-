import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base "./" → works from any folder / sub-path (Vercel, Netlify, GitHub Pages...)
export default defineConfig({
  base: "./",
  plugins: [react()],
});
