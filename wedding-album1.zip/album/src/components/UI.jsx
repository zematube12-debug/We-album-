import { useAtom } from "jotai";
import { useCallback, useEffect, useRef, useState } from "react";
import { ALBUM } from "../album.config";
import { pageAtom, pages } from "../album";

const BASE = import.meta.env.BASE_URL;

export const UI = () => {
  const [page, setPage] = useAtom(pageAtom);
  const [started, setStarted] = useState(false);
  const [muted, setMuted] = useState(false);
  const [hintDismissed, setHintDismissed] = useState(false);
  const [isFull, setIsFull] = useState(false);
  const [barVisible, setBarVisible] = useState(true);
  const first = useRef(true);
  const press = useRef(null);
  const hideTimer = useRef(null);

  const next = useCallback(
    () => setPage((p) => Math.min(pages.length, p + 1)),
    [setPage]
  );
  const prev = useCallback(
    () => setPage((p) => Math.max(0, p - 1)),
    [setPage]
  );

  // controls fade away after 3 s so the album fills the screen
  const showBar = useCallback(() => {
    setBarVisible(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setBarVisible(false), 3000);
  }, []);
  useEffect(() => {
    if (started) showBar();
    return () => clearTimeout(hideTimer.current);
  }, [started, showBar]);

  // page-flip sound
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    if (muted) return;
    const audio = new Audio(`${BASE}audios/page-flip-01a.mp3`);
    audio.play().catch(() => {});
  }, [page]);

  // keyboard
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "ArrowRight" || e.key === " ") next();
      if (e.key === "ArrowLeft") prev();
      showBar();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [next, prev, showBar]);

  useEffect(() => {
    const onFs = () => setIsFull(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  // One tap = full screen + landscape (browsers only allow this after a tap)
  const openAlbum = async () => {
    try {
      await document.documentElement.requestFullscreen?.({
        navigationUI: "hide",
      });
    } catch (e) {}
    try {
      await screen.orientation?.lock?.("landscape");
    } catch (e) {}
    setStarted(true);
  };

  // swipe left/right = turn page,  tap right half = next,  tap left half = back
  const onPointerDown = (e) => {
    press.current = { x: e.clientX, y: e.clientY };
    showBar();
  };
  const onPointerUp = (e) => {
    if (!press.current) return;
    const dx = e.clientX - press.current.x;
    const dy = e.clientY - press.current.y;
    press.current = null;
    if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) {
      dx < 0 ? next() : prev();
    } else if (Math.abs(dx) < 12 && Math.abs(dy) < 12) {
      e.clientX > window.innerWidth / 2 ? next() : prev();
    }
  };

  const toggleFullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen?.().catch(() => {});
  };

  const label =
    page === 0
      ? "Cover"
      : page === pages.length
      ? "Back cover"
      : `${page} / ${pages.length - 1}`;

  const fade = `transition-opacity duration-500 ${
    barVisible ? "opacity-100" : "opacity-0 pointer-events-none"
  }`;

  return (
    <>
      {/* gesture layer */}
      <div
        className="fixed inset-0 z-10"
        style={{ touchAction: "none" }}
        onPointerDown={onPointerDown}
        onPointerUp={onPointerUp}
        onPointerCancel={() => (press.current = null)}
      />

      {/* title */}
      <div
        className={`fixed top-3 left-4 z-20 pointer-events-none select-none text-white/70 ${fade}`}
      >
        <div className="text-[10px] tracking-[0.35em] uppercase">
          {ALBUM.subtitle}
        </div>
        <div className="text-sm font-light italic">{ALBUM.title}</div>
      </div>

      {/* top-right buttons */}
      <div className={`fixed top-3 right-4 z-20 flex gap-2 ${fade}`}>
        <button
          className="w-9 h-9 rounded-full bg-black/40 text-white text-sm border border-white/20"
          onClick={() => setMuted((m) => !m)}
          aria-label="sound"
        >
          {muted ? "🔇" : "🔊"}
        </button>
        {document.fullscreenEnabled && (
          <button
            className="w-9 h-9 rounded-full bg-black/40 text-white text-sm border border-white/20"
            onClick={toggleFullscreen}
            aria-label="fullscreen"
          >
            {isFull ? "✕" : "⛶"}
          </button>
        )}
      </div>

      {/* bottom bar */}
      <div
        className={`fixed bottom-2 left-0 right-0 z-20 flex items-center justify-center gap-3 px-6 select-none ${fade}`}
      >
        <button
          className="w-9 h-9 rounded-full bg-black/40 text-white border border-white/20 disabled:opacity-30"
          onClick={prev}
          disabled={page === 0}
          aria-label="previous"
        >
          ‹
        </button>
        <input
          type="range"
          min={0}
          max={pages.length}
          value={page}
          onChange={(e) => setPage(Number(e.target.value))}
          className="album-range w-full max-w-md"
          aria-label="page"
        />
        <button
          className="w-9 h-9 rounded-full bg-black/40 text-white border border-white/20 disabled:opacity-30"
          onClick={next}
          disabled={page === pages.length}
          aria-label="next"
        >
          ›
        </button>
        <span className="text-white/70 text-xs w-20 text-left">{label}</span>
      </div>

      {/* still in portrait (e.g. iPhone can't lock rotation) */}
      {started && !hintDismissed && (
        <div
          className="rotate-hint fixed inset-0 z-30 bg-black/85 text-white flex-col items-center justify-center gap-5 text-center px-8"
          onClick={() => setHintDismissed(true)}
        >
          <div className="rotate-phone text-6xl">📱</div>
          <div className="text-xl">ስልክዎን በጎን (landscape) ያዙት</div>
          <div className="text-sm text-white/60">
            Rotate your phone to open the album
          </div>
          <div className="text-xs text-white/40 mt-6">tap to continue anyway</div>
        </div>
      )}

      {/* start screen: one tap → full screen + landscape */}
      {!started && (
        <div className="fixed inset-0 z-40 bg-[#14110f] flex flex-col items-center justify-center gap-5 text-center px-8">
          <div className="text-xs tracking-[0.4em] uppercase text-[#c9a961]">
            {ALBUM.subtitle}
          </div>
          <div className="text-white text-3xl font-light italic">
            {ALBUM.title}
          </div>
          <button
            className="mt-2 px-8 py-3 rounded-full bg-[#c9a961] text-black font-semibold"
            onClick={openAlbum}
          >
            አልበሙን ክፈት · Open album
          </button>
          <div className="text-white/40 text-xs">
            ሙሉ ስክሪን እና landscape በራሱ ይሆናል
          </div>
        </div>
      )}
    </>
  );
};
