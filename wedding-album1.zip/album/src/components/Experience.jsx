import { Environment, Float } from "@react-three/drei";
import { useThree } from "@react-three/fiber";
import { useEffect } from "react";
import { ALBUM } from "../album.config";
import { COVER_HEIGHT, PAGE_WIDTH } from "../album";
import { Book } from "./Book";

// Slight "looking down at a table" tilt, like a real photo of an album.
// Set to 0 for a perfectly straight-on view.
const TABLE_TILT = ALBUM.look.tilt;

// Moves the camera so the whole open album (two pages) always fits the
// screen — phone in landscape, tablet, laptop.
const CameraRig = () => {
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);
  const scene = useThree((s) => s.scene);

  useEffect(() => {
    // strength of the studio reflections on the glossy paper
    scene.environmentIntensity = ALBUM.look.reflections;
  }, [scene]);

  useEffect(() => {
    const aspect = size.width / size.height;
    const t = Math.tan((camera.fov * Math.PI) / 360);
    const needW = PAGE_WIDTH * 2 * 1.13;
    const needH = COVER_HEIGHT * Math.cos(TABLE_TILT) * 1.3;
    const distance = Math.max(needH / (2 * t), needW / (2 * t * aspect));
    camera.position.set(0, 0, distance);
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();
  }, [size, camera]);

  return null;
};

export const Experience = () => {
  return (
    <>
      <CameraRig />
      <group rotation-x={-TABLE_TILT}>
        <Float
          floatIntensity={0.15}
          rotationIntensity={0.08}
          speed={1.2}
          floatingRange={[-0.005, 0.005]}
        >
          <Book />
        </Float>
        {/* the "table": only catches the album's soft shadow */}
        <mesh position-z={-0.09} receiveShadow>
          <planeGeometry args={[40, 40]} />
          <shadowMaterial transparent opacity={0.3} />
        </mesh>
      </group>

      <Environment preset="studio" />
      {/* even, soft light: a broad fill + one gentle key light */}
      <ambientLight intensity={1.0} />
      <directionalLight
        position={[-2.5, 3, 5]}
        intensity={1.6}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-bias={-0.0002}
      />
    </>
  );
};
