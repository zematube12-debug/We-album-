// ============================================================
//  እዚህ ፋይል ብቻ ነው አልበሙን የምትቀይረው  /  EDIT ONLY THIS FILE
// ============================================================
const BASE = import.meta.env.BASE_URL;
const A = (file) => `${BASE}album/${file}`;

export const ALBUM = {
  title: "Our Wedding",
  subtitle: "YAM PICTURE",

  // የአንድ ገጽ ስፋት ÷ ቁመት።  36×12 spread = ሁለት 18×12 ገጾች = 18/12
  // Width ÷ height of ONE page. A 36x12 spread = two 18x12 pages.
  pageRatio: 18 / 12,

  cover: A("cover.jpg"),
  backCover: A("back.jpg"),

  // እያንዳንዱ ግቤት አንድ spread ነው፦
  //  - "spread-01.jpg"            → አንድ ሙሉ ምስል (3:1)፣ መሃሉ ላይ በራሱ ለሁለት ይቆረጣል
  //  - { left: "a.jpg", right: "b.jpg" } → ሁለት የተለያዩ ምስሎች (እያንዳንዱ ገጽ አንድ)
  spreads: [
    A("spread-01.jpg"),
    A("spread-02.jpg"),
    A("spread-03.jpg"),
    A("spread-04.jpg"),
    A("spread-05.jpg"),
    A("spread-06.jpg"),
    A("spread-07.jpg"),
  ],
};
