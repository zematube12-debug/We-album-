import { useTexture } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useAtom } from "jotai";
import { easing } from "maath";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Bone,
  BoxGeometry,
  Color,
  Float32BufferAttribute,
  MeshStandardMaterial,
  Skeleton,
  SkinnedMesh,
  SRGBColorSpace,
  Uint16BufferAttribute,
  Vector3,
} from "three";
import { degToRad } from "three/src/math/MathUtils.js";
import { ALBUM } from "../album.config";
import {
  COVER_DEPTH,
  COVER_HEIGHT,
  COVER_WIDTH,
  PAGE_DEPTH,
  PAGE_HEIGHT,
  PAGE_WIDTH,
  pageAtom,
  pages,
  uniqueTextures,
} from "../album";

const easingFactor = 0.5; // Controls the speed of the easing
const easingFactorFold = 0.3; // Controls the speed of the easing
const insideCurveStrength = 0.18; // Controls the strength of the curve
const outsideCurveStrength = 0.05; // Controls the strength of the curve
const turningCurveStrength = 0.09; // Controls the strength of the curve

const PAGE_SEGMENTS = 30;

// ---------- geometry (one for paper pages, one for hard covers) ----------
const createSkinnedGeometry = (width, height, depth) => {
  const segmentWidth = width / PAGE_SEGMENTS;
  const geometry = new BoxGeometry(width, height, depth, PAGE_SEGMENTS, 2);
  geometry.translate(width / 2, 0, 0);

  const position = geometry.attributes.position;
  const vertex = new Vector3();
  const skinIndexes = [];
  const skinWeights = [];

  for (let i = 0; i < position.count; i++) {
    vertex.fromBufferAttribute(position, i);
    const x = vertex.x;
    const skinIndex = Math.max(0, Math.floor(x / segmentWidth));
    const skinWeight = (x % segmentWidth) / segmentWidth;
    skinIndexes.push(skinIndex, skinIndex + 1, 0, 0);
    skinWeights.push(1 - skinWeight, skinWeight, 0, 0);
  }

  geometry.setAttribute("skinIndex", new Uint16BufferAttribute(skinIndexes, 4));
  geometry.setAttribute(
    "skinWeight",
    new Float32BufferAttribute(skinWeights, 4)
  );
  return { geometry, segmentWidth };
};

const paperGeo = createSkinnedGeometry(PAGE_WIDTH, PAGE_HEIGHT, PAGE_DEPTH);
const coverGeo = createSkinnedGeometry(COVER_WIDTH, COVER_HEIGHT, COVER_DEPTH);

const whiteColor = new Color("white");
const paperEdge = new Color("#f3ede2");
const leatherEdge = new Color("#2a1116");

const paperSideMaterials = [
  new MeshStandardMaterial({ color: paperEdge }),
  new MeshStandardMaterial({ color: "#111" }),
  new MeshStandardMaterial({ color: paperEdge }),
  new MeshStandardMaterial({ color: paperEdge }),
];
const coverSideMaterials = [
  new MeshStandardMaterial({ color: leatherEdge }),
  new MeshStandardMaterial({ color: leatherEdge }),
  new MeshStandardMaterial({ color: leatherEdge }),
  new MeshStandardMaterial({ color: leatherEdge }),
];

useTexture.preload(uniqueTextures);

// Crop-to-fill ("object-fit: cover") a texture onto a page, and pick the
// left / right half when the image is a whole spread.
const useFittedTexture = (texture, side, ratio) =>
  useMemo(() => {
    const t = texture.clone();
    t.colorSpace = SRGBColorSpace;
    t.anisotropy = 8;
    const iw = texture.image.width;
    const ih = texture.image.height;

    let regionAspect = iw / ih;
    let regionX = 0;
    let regionW = 1;
    if (side.part === "left") {
      regionAspect = iw / 2 / ih;
      regionW = 0.5;
    } else if (side.part === "right") {
      regionAspect = iw / 2 / ih;
      regionX = 0.5;
      regionW = 0.5;
    }

    let fitW = 1;
    let fitH = 1;
    if (regionAspect > ratio) fitW = ratio / regionAspect;
    else fitH = regionAspect / ratio;

    t.repeat.set(regionW * fitW, fitH);
    t.offset.set(regionX + (regionW * (1 - fitW)) / 2, (1 - fitH) / 2);
    t.needsUpdate = true;
    return t;
  }, [texture, side.src, side.part, ratio]);

const Page = ({ number, front, back, hard, page, opened, bookClosed }) => {
  const { geometry, segmentWidth } = hard ? coverGeo : paperGeo;
  const ratio = hard ? COVER_WIDTH / COVER_HEIGHT : ALBUM.pageRatio;

  const [frontTex, backTex] = useTexture([front.src, back.src]);
  const picture = useFittedTexture(frontTex, front, ratio);
  const picture2 = useFittedTexture(backTex, back, ratio);

  const group = useRef();
  const turnedAt = useRef(0);
  const lastOpened = useRef(opened);
  const skinnedMeshRef = useRef();

  const manualSkinnedMesh = useMemo(() => {
    const bones = [];
    for (let i = 0; i <= PAGE_SEGMENTS; i++) {
      const bone = new Bone();
      bones.push(bone);
      bone.position.x = i === 0 ? 0 : segmentWidth;
      if (i > 0) bones[i - 1].add(bone);
    }
    const skeleton = new Skeleton(bones);

    const finish = hard
      ? { roughness: 0.55, metalness: 0.05 }
      : { roughness: 0.2, metalness: 0 };

    const materials = [
      ...(hard ? coverSideMaterials : paperSideMaterials),
      new MeshStandardMaterial({ color: whiteColor, map: picture, ...finish }),
      new MeshStandardMaterial({ color: whiteColor, map: picture2, ...finish }),
    ];
    const mesh = new SkinnedMesh(geometry, materials);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.frustumCulled = false;
    mesh.add(skeleton.bones[0]);
    mesh.bind(skeleton);
    return mesh;
  }, [picture, picture2]);

  useFrame((_, delta) => {
    if (!skinnedMeshRef.current) return;

    if (lastOpened.current !== opened) {
      turnedAt.current = +new Date();
      lastOpened.current = opened;
    }
    let turningTime = Math.min(400, new Date() - turnedAt.current) / 400;
    turningTime = Math.sin(turningTime * Math.PI);

    let targetRotation = opened ? -Math.PI / 2 : Math.PI / 2;
    if (!bookClosed) {
      targetRotation += degToRad(number * 0.8);
    }

    const bones = skinnedMeshRef.current.skeleton.bones;
    for (let i = 0; i < bones.length; i++) {
      const target = i === 0 ? group.current : bones[i];

      const insideCurveIntensity = i < 8 ? Math.sin(i * 0.2 + 0.25) : 0;
      const outsideCurveIntensity = i >= 8 ? Math.cos(i * 0.3 + 0.09) : 0;
      const turningIntensity =
        Math.sin(i * Math.PI * (1 / bones.length)) * turningTime;
      let rotationAngle =
        insideCurveStrength * insideCurveIntensity * targetRotation -
        outsideCurveStrength * outsideCurveIntensity * targetRotation +
        turningCurveStrength * turningIntensity * targetRotation;
      let foldRotationAngle = degToRad(Math.sign(targetRotation) * 2);
      if (bookClosed) {
        if (i === 0) {
          rotationAngle = targetRotation;
          foldRotationAngle = 0;
        } else {
          rotationAngle = 0;
          foldRotationAngle = 0;
        }
      }
      easing.dampAngle(target.rotation, "y", rotationAngle, easingFactor, delta);

      const foldIntensity =
        i > 8
          ? Math.sin(i * Math.PI * (1 / bones.length) - 0.5) * turningTime
          : 0;
      easing.dampAngle(
        target.rotation,
        "x",
        foldRotationAngle * foldIntensity,
        easingFactorFold,
        delta
      );
    }
  });

  return (
    <group ref={group}>
      <primitive
        object={manualSkinnedMesh}
        ref={skinnedMeshRef}
        position-z={-number * PAGE_DEPTH + page * PAGE_DEPTH}
      />
    </group>
  );
};

export const Book = ({ ...props }) => {
  const [page] = useAtom(pageAtom);
  const [delayedPage, setDelayedPage] = useState(page);
  const shift = useRef();

  useEffect(() => {
    let timeout;
    const goToPage = () => {
      setDelayedPage((delayedPage) => {
        if (page === delayedPage) {
          return delayedPage;
        } else {
          timeout = setTimeout(
            () => {
              goToPage();
            },
            Math.abs(page - delayedPage) > 2 ? 50 : 150
          );
          if (page > delayedPage) return delayedPage + 1;
          if (page < delayedPage) return delayedPage - 1;
        }
      });
    };
    goToPage();
    return () => {
      clearTimeout(timeout);
    };
  }, [page]);

  const closedFront = delayedPage === 0;
  const closedBack = delayedPage === pages.length;

  // keep the book centred: a closed book only fills one half of the spread
  useFrame((_, delta) => {
    if (!shift.current) return;
    const targetX = closedFront
      ? -PAGE_WIDTH / 2
      : closedBack
      ? PAGE_WIDTH / 2
      : 0;
    easing.damp(shift.current.position, "x", targetX, 0.35, delta);
  });

  return (
    <group ref={shift} {...props}>
      <group rotation-y={-Math.PI / 2}>
        {pages.map((pageData, index) => (
          <Page
            key={index}
            page={delayedPage}
            number={index}
            opened={delayedPage > index}
            bookClosed={closedFront || closedBack}
            {...pageData}
          />
        ))}
      </group>
    </group>
  );
};
