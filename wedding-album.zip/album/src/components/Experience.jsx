import { Environment, Float } from "@react-three/drei";
import { useThree } from "@react-three/fiber";
import { useEffect } from "react";
import { COVER_HEIGHT, PAGE_WIDTH } from "../album";
import { Book } from "./Book";

// Moves the camera so the whole open album (two pages) always fits the
// screen — phone in landscape, tablet, laptop.
const CameraRig = () => {
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);

  useEffect(() => {
    const aspect = size.width / size.height;
    const t = Math.tan((camera.fov * Math.PI) / 360);
    const needW = PAGE_WIDTH * 2 * 1.14;
    const needH = COVER_HEIGHT * 1.32; // spare room for the bottom bar
    const distance = Math.max(needH / (2 * t), needW / (2 * t * aspect));
    camera.position.set(0, -0.02, distance);
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();
  }, [size, camera]);

  return null;
};

export const Experience = () => {
  return (
    <>
      <CameraRig />
      <Float
        floatIntensity={0.25}
        rotationIntensity={0.2}
        speed={1.4}
        floatingRange={[-0.01, 0.01]}
      >
        <Book />
      </Float>
      <Environment preset="studio" />
      <directionalLight
        position={[2.5, 3.5, 5]}
        intensity={2.2}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-bias={-0.0002}
      />
      {/* soft shadow of the album on the "table" behind it */}
      <mesh position-z={-0.3} receiveShadow>
        <planeGeometry args={[40, 40]} />
        <shadowMaterial transparent opacity={0.35} />
      </mesh>
    </>
  );
};
