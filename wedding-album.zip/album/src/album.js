import { atom } from "jotai";
import { ALBUM } from "./album.config";

export const pageAtom = atom(0);

// ---- geometry sizes (world units) ----
export const PAGE_HEIGHT = 1.2;
export const PAGE_WIDTH = PAGE_HEIGHT * ALBUM.pageRatio;
export const PAGE_DEPTH = 0.004;
// hard cover: slightly bigger than the pages (overhang) and thicker
export const COVER_WIDTH = PAGE_WIDTH * 1.03;
export const COVER_HEIGHT = PAGE_HEIGHT * 1.06;
export const COVER_DEPTH = 0.014;

// ---- turn spreads into page "sides" (left, right, left, right ...) ----
const sides = [];
ALBUM.spreads.forEach((s) => {
  if (typeof s === "string") {
    sides.push({ src: s, part: "left" }, { src: s, part: "right" });
  } else {
    sides.push({ src: s.left, part: "full" }, { src: s.right, part: "full" });
  }
});
if (sides.length % 2 === 1) {
  sides.push({ src: ALBUM.cover, part: "full" });
}

// ---- leaves (a leaf = one physical sheet: front + back) ----
// leaf 0   : front = cover,       back = left of spread 1
// leaf i   : front = right of spread i, back = left of spread i+1
// leaf last: front = right of last spread, back = back cover
const spreadCount = sides.length / 2;
export const pages = [];
pages.push({
  front: { src: ALBUM.cover, part: "full" },
  back: sides[0],
  hard: true,
});
for (let i = 1; i < spreadCount; i++) {
  pages.push({ front: sides[2 * i - 1], back: sides[2 * i], hard: false });
}
pages.push({
  front: sides[sides.length - 1],
  back: { src: ALBUM.backCover, part: "full" },
  hard: true,
});

export const uniqueTextures = [
  ...new Set(pages.flatMap((p) => [p.front.src, p.back.src])),
];
