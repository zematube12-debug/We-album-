# Wedding Album (3D page-flip) — YAM PICTURE

React + Three.js (React Three Fiber) የሚሰራ እውነተኛ-መሰል የሰርግ አልበም። ስልክ landscape ሲይዙ ሁለት ገጾች (ግራ/ቀኝ) እንደ እውነተኛ አልበም ይታያሉ።

## አስኪድ
    npm install
    npm run dev -- --host      # በስልክህ ለመሞከር: በ Wi-Fi የሚታየውን አድራሻ ስልክ ላይ ክፈት
    npm run build              # → dist/ አቃፊ  (Vercel / Netlify ላይ ጫን)

## የራስህን አልበም ለመስራት
1. spread ምስሎችህን (ከAlbum Studio) እንደ JPG አውጣ፦ **3000×1000 px** (36×12 ሬሾ)፣ ጥራት 80–85፣ እያንዳንዱ ≤ 500KB።
2. `public/album/` ውስጥ አስገባ፤ እንዲሁም `cover.jpg` እና `back.jpg` (1560×1050).
3. `src/album.config.js` ክፈት፤ `title`፣ `spreads` ዝርዝሩን አስተካክል።
   - ሌላ መጠን ከሆነ `pageRatio` ቀይር (ለምሳሌ 12×18 ገጽ → 12/18 ወይም ሁለት ገጽ 24×12 → 12/12).

## መቆጣጠሪያ
swipe ግራ/ቀኝ · የግራ/ቀኝ ግማሽ ስክሪን tap · ቀስቶች · slider · ← → ቁልፎች

## ፋይሎች
- `src/album.config.js` — የምትቀይረው ብቸኛ ፋይል
- `src/album.js` — spreads → ገጾች (leaf) ስሌት እና መጠኖች
- `src/components/Book.jsx` — 3D ገጽ፣ ማጠፍ፣ cover ውፍረት፣ ምስል መቁረጥ
- `src/components/Experience.jsx` — camera ማስተካከያ፣ ብርሃን፣ ጥላ
- `src/components/UI.jsx` — swipe/tap፣ ቁልፎች፣ ድምፅ፣ "ስልክ አዙር" መልዕክት
